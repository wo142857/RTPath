module("LOCAL_APP_LIST")


OWN_LIST = {
}
