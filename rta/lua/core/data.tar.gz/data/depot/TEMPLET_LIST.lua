module("TEMPLET_LIST")


OWN_LIST = {
	EXACT_NAME = {
	},
	EXACT_INFO = {
	},

	LOCAL_NAME = {
	},
	LOCAL_INFO = {
	},

	WHOLE_NAME = {
	},
	WHOLE_INFO = {
	},

	ALONE_NAME = {
	},
	ALONE_INFO = {
	}
}
