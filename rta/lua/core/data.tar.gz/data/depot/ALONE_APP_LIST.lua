module("ALONE_APP_LIST")


OWN_LIST = {
}
